/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabajo.teoria;


public class Clase { 
  public static int Residentes = 0;
  public static String[] A = new String[20];
  public static String[] H = new String[20];
  public static String[] T = new String[20];
  public static String[] R = new String[20];
  public static String[] Es = new String[20];
  public static String[] Ea = new String[20];
  public static String[] diat = new String[20];
  int numero_residentes;
  public static String[] Nombre = new String[20];
  public static String[] Apellido = new String[20];
  public static String[] Documento = new String[20];
  public static String[] No_Turno = new String[20];
  public static int[] Año = new int[20];
  public static int[] Hora = new int[20];
  public static int[] Turno = new int[20];
  public static int[] Refuerzo = new int[20];
  public static int[] Especialidad = new int[20];
  public static int[] EspeActual = new int[20];
  
  
}
